/* To avoid CSS expressions while still supporting IE 7 and IE 6, use this script */
/* The script tag referencing this file must be placed before the ending body tag. */

/* Use conditional comments in order to target IE 7 and older:
	<!--[if lt IE 8]><!-->
	<script src="ie7/ie7.js"></script>
	<!--<![endif]-->
*/

(function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'PWA-Home-Icons\'">' + entity + '</span>' + html;
	}
	var icons = {
		'icon-Polpay-Arm---Fill': '&#xe944;',
		'icon-Polpay-Arm---Outline': '&#xe945;',
		'icon-scheduled-transfer-fill': '&#xe908;',
		'icon-scheduled-transfer-outline': '&#xe909;',
		'icon-normal-transfer-fill': '&#xe930;',
		'icon-normal-transfer-outline': '&#xe931;',
		'icon-card-to-card-fill': '&#xe942;',
		'icon-card-to-card-outline': '&#xe943;',
		'icon-map': '&#xe900;',
		'icon-map-fill': '&#xe901;',
		'icon-shoab': '&#xe902;',
		'icon-shoab-fill': '&#xe903;',
		'icon-new-deposit': '&#xe904;',
		'icon-new-deposit-fill': '&#xe905;',
		'icon-cards': '&#xe906;',
		'icon-cards-fill': '&#xe907;',
		'icon-Ghabz': '&#xe90a;',
		'icon-Ghabz-fill': '&#xe90b;',
		'icon-gozaresh': '&#xe90c;',
		'icon-gozaresh-fill': '&#xe90d;',
		'icon-Home-outline': '&#xe90e;',
		'icon-Home-fill': '&#xe90f;',
		'icon-Karpoushe': '&#xe910;',
		'icon-Karpoushe-fill': '&#xe911;',
		'icon-khadamat-pardakht': '&#xe912;',
		'icon-khadamat-pardakht-Fill': '&#xe913;',
		'icon-Nerkh-soud': '&#xe914;',
		'icon-Nerkh-soud-fill': '&#xe915;',
		'icon-Profile-outline': '&#xe916;',
		'icon-Profile-fill': '&#xe917;',
		'icon-Ramzsaz': '&#xe918;',
		'icon-Ramzsaz-fill': '&#xe919;',
		'icon-Sheba': '&#xe91a;',
		'icon-Sheba-fill': '&#xe91b;',
		'icon-Sherkatyar': '&#xe91c;',
		'icon-Sherkatyar-fill': '&#xe91d;',
		'icon-Sigma': '&#xe91e;',
		'icon-Sigma-fill': '&#xe91f;',
		'icon-simcard': '&#xe920;',
		'icon-simcard-fill': '&#xe921;',
		'icon-tamasha': '&#xe922;',
		'icon-tamasha-fill': '&#xe923;',
		'icon-tarikhche': '&#xe924;',
		'icon-tarikhche-fill': '&#xe925;',
		'icon-Tashilat': '&#xe926;',
		'icon-Tashilat-fill': '&#xe927;',
		'icon-transfer': '&#xe928;',
		'icon-transfer-fill': '&#xe929;',
		'icon-wistore': '&#xe92a;',
		'icon-wistore-fill': '&#xe92b;',
		'icon-wistore-app': '&#xe92c;',
		'icon-wistore-app-fill': '&#xe92d;',
		'icon-asnad': '&#xe92e;',
		'icon-asnad-fill': '&#xe92f;',
		'icon-Bazar-sarmaye': '&#xe932;',
		'icon-Bazar-sarmaye-fill': '&#xe933;',
		'icon-card': '&#xe934;',
		'icon-card-fill': '&#xe935;',
		'icon-Card-seporde-Outline': '&#xe936;',
		'icon-Card-seporde-fill': '&#xe937;',
		'icon-cheque-book': '&#xe938;',
		'icon-cheque-book-fill': '&#xe939;',
		'icon-daryaft-bedune-cart': '&#xe93a;',
		'icon-daryaft-bedune-cart-fill': '&#xe93b;',
		'icon-Dashboard-outline': '&#xe93c;',
		'icon-Dashboard-fill': '&#xe93d;',
		'icon-e-gift': '&#xe93e;',
		'icon-e-gift-fill': '&#xe93f;',
		'icon-Emza-digital': '&#xe940;',
		'icon-Emza-digital-fill': '&#xe941;',
		'0': 0
		},
		els = document.getElementsByTagName('*'),
		i, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		c = el.className;
		c = c.match(/icon-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
}());
